package ar.com.eduit.curso.java.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {
    private static String driver="org.mariadb.jdbc.Driver";                     //mariadb
    //private static String driver="com.mysql.jdbc.Driver";                       //mysql 5
    //private static String driver="com.mysql.cj.jdbc.Driver";                    //mysql 6 o sup.
    private static String url="jdbc:mariadb://localhost:3306/colegio?serverTimezone=UTC";
    //private static String url="jdbc:mariadb://freedb.tech:3306/freedbtech_colegio?serverTimezone=UTC";
    private static String user="root";
    //private static String user="freedbtech_colegio";
    private static String pass="";
    //private static String pass="colegio";
    private static Connection conn=null;
    private Connector(){}
    
    public static synchronized Connection getConnection(){
        try{
            if(conn==null || conn.isClosed()){
                Class.forName(driver);
                conn=DriverManager.getConnection(url, user, pass);
            }
        }catch(Exception e){
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
        }
        return conn;
    }
}