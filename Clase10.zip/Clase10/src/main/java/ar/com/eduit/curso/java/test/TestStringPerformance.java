package ar.com.eduit.curso.java.test;

public class TestStringPerformance {
    public static void main(String[] args) {
        //String txt="";
        //for(int a=1;a<=500000;a++) txt+="x";
          
        StringBuilder sb=new StringBuilder();
        for(int a=1;a<=1500000;a++) sb.append("x");
        
    }
}