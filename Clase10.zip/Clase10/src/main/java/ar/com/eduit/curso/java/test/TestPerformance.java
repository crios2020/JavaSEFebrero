package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;
import java.time.LocalTime;
import java.util.List;

public class TestPerformance {
    public static void main(String[] args) {
        LocalTime ltInicio=LocalTime.now();
        System.out.println(ltInicio);
        I_CursoRepository cr=new CursoRepository(Connector.getConnection());
        cr.getAll().forEach(System.out::println);
        LocalTime ltFinal=LocalTime.now();
        System.out.println(ltFinal);
    }
}