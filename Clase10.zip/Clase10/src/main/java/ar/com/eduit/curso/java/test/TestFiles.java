package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.utils.files.FileText;
import ar.com.eduit.curso.java.utils.files.I_File;
import java.util.List;

public class TestFiles {
    public static void main(String[] args) {
        I_File file=new FileText("texto.txt");
        
        file.setText("Curso de Java!\n");
        file.appendText("Hoy es sábado!\n");
        file.addLine("Primavera.");
        file.addLine("Verano.");
        file.addLine("Otoño.");
        file.addLine("Invierno.");
        file.addLine("Verano.");
        file.addLine("Lunes.");
        file.addLine("Martes.");
        file.addLine("Martes.");
        file.addLine("Miércoles.");
        file.addLine("Jueves.");
        file.addLine("Viernes.");
        file.addLine("Sábado.");
        file.addLine("Domingo.");
        
        file.remove("Invierno.");
        
        List<String>list=List.of("Rojo","Verde","Azul","Blanco","Gris","Negro");
        file.addLines(list);
        
        //System.out.println(file.getText());
        //file.print();
        
        file.getAll().forEach(System.out::println);
        //file.getLikeFilter("VE").forEach(System.out::println);
        //file.getLinkedHashSet().forEach(System.out::println);
        //file.getTreeSet().forEach(System.out::println);
        
        
        
        /*
        String texto="";
        
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="h";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="o";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="l";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="a";
        System.out.println(texto+"\t"+texto.hashCode());
        
        //StringBuffer StringBuilder
        StringBuilder sb=new StringBuilder();
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("h");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("o");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("l");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("a");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        */
        
    }
}