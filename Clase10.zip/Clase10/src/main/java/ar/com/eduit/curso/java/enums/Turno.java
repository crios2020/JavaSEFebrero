package ar.com.eduit.curso.java.enums;
public enum Turno { MAÑANA,TARDE,NOCHE }