package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;
import java.util.List;

public class TestRepository {
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository(Connector.getConnection());
        Curso curso=new Curso("HTML", "Segovia", Dia.MARTES, Turno.NOCHE);
        cr.save(curso);
        System.out.println(curso);
        
        curso=cr.getById(2);
        System.out.println(curso);
        
        cr.remove(cr.getById(7));
        
        curso=cr.getById(6);
        curso.setTurno(Turno.MAÑANA);
        cr.update(curso);
        
        System.out.println("**************************************************");
        List<Curso>list=cr.getAll();
        for(int a=0;a<list.size();a++) System.out.println(list.get(a));
        
        System.out.println("**************************************************");
        list=cr.getLikeTitulo("ja");
        for(int a=0;a<list.size();a++) System.out.println(list.get(a));
    }
}