package colleciones;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

public class CollectionsApp {
    public static void main(String[] args) {
        
        // Vectores o Arrays
        Auto[] autos=new Auto[4];
        autos[0]=new Auto("Ford","Fiesta","Blanco");
        autos[1]=new Auto("VW","UP","Negro");
        autos[2]=new Auto("Citroen","Berlingo","Bordo");
        autos[3]=new Auto("Renault","Kangoo","Amarillo");

        // Recorrido con indices
        //for(int a=0;a<autos.length;a++) System.out.println(autos[a]);

        // Recorrido forEach JDK 5 o sup.
        for(Auto a:autos) System.out.println(a);

        // Framework Collections


        // Interface List.
        List lista1;
        lista1=new ArrayList();
        //lista1=new LinkedList();
        //lista1=new Vector();
        
        lista1.add(new Auto("Fiat","Idea","Gris"));         // 0
        lista1.add(new Auto("Fiat","Chronos","Verde"));     // 1
        lista1.add(new Auto("Peugeot","3008","Gris"));      // 2
        lista1.add("Hola");                                 // 3
        lista1.add(44);                                     // 4
        //lista1.remove(3);
        lista1.add(1,"Sábado");

        //copiar los autos del vector autos a lista1
        //for(Auto a:autos) lista1.add(a);
        lista1.addAll(Arrays.asList(autos));
        
        System.out.println("**********************************************");
        // recorrido con indices
        //for(int a=0;a<lista1.size();a++) System.out.println(lista1.get(a));

        // recorrido forEach
        //for(Object o:lista1) System.out.println(o);
        
        // método forEach() java 8 o sup.
        //lista1.forEach(x->System.out.println(x));
        //lista1.forEach(x->{
        //    System.out.print("-");
        //    System.out.println(x);
        //});
        
        lista1.forEach(System.out::println);
        
        //Uso de Generics<> Java 5 o sup.
        List<Auto>lista2=new ArrayList();
        lista2.add(new Auto("Ford","Ka","Negro"));
        
        
        Auto a1=(Auto)lista1.get(0);
        Auto a2=lista2.get(0);
        
        //copiar autos de lista1 a lista2
        lista1.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o);
        });
        
        System.out.println("**********************************************");
        lista2.forEach(System.out::println);
        
        
        //interface Set
        Set<String>set;
        
        //Implementación HashSet: Es la implementación es las más veloz.
        //  No garantiza el orden de los elementos.
        
        //set=new HashSet();
        
        //Implementación LinkedHashSet: Almacena elementos en una lista enlazada
        // por orden de ingreso.
        set=new LinkedHashSet();
        
        //Implementación TreeSet: Almacena elementos en un arbol por orden natural
        set=new TreeSet();
        
        set.add("Lunes");
        set.add("Martes");
        set.add("d");
        set.add("z");
        set.add("b");
        set.add("c");
        set.add("a");
        set.add("Miércoles");
        set.add("Lunes");
        set.add("Jueves");
        set.add("Viernes");
        set.add("Viernes");
        set.add("Viernes");
        set.add("Viernes");
        set.add("Viernes");
        set.add("Sábado");
        set.add("Domingo");
        System.out.println("****************************************************");
        System.out.println("Longitud de set: "+set.size());
        set.forEach(System.out::println);
        
        
        Set<Auto>setAutos;
        //setAutos=new LinkedHashSet();
        //setAutos=new HashSet();
        setAutos=new TreeSet();
        setAutos.addAll(lista2);
        setAutos.add(new Auto("Ford","Ka","Negro"));
        setAutos.add(new Auto("Ford","Ka","Blanco"));
        
        System.out.println("****************************************************");
        setAutos.forEach(auto->System.out.println(auto+"\t"+auto.hashCode()));
        
        // Colas            FIFO (First In First Out)
        ArrayDeque<Auto>colaAutos=new ArrayDeque();
        colaAutos.offer(new Auto("Renault","Clio","Azul"));
        // .offer encola un elemento en la cola.
        colaAutos.addAll(lista2);
        System.out.println("****************************************************");
        colaAutos.forEach(System.out::println);
        System.out.println("****************************************************");
        System.out.println("Longitud Cola Autos: "+colaAutos.size());
        while(!colaAutos.isEmpty()){
            System.out.println(colaAutos.poll());
            // .poll desencolar un elemento de la cola.
        }
        System.out.println("Longitud Cola Autos: "+colaAutos.size());
        
        
        // Pilas            LIFO (Last In First Out)
        Stack<Auto> pilaAutos=new Stack();
        pilaAutos.push(new Auto("Ford","Mondeo","Gris"));
        // .push() apila un elemento en la pila.
        pilaAutos.addAll(lista2);
        
        System.out.println("****************************************************");
        pilaAutos.forEach(System.out::println);
        
        System.out.println("****************************************************");
        System.out.println("Longitud de pilaAutos: "+pilaAutos.size());
        while(!pilaAutos.isEmpty()){
            System.out.println(pilaAutos.pop());
            // .pop() desapila un elemento
        }
        System.out.println("Longitud de pilaAutos: "+pilaAutos.size());
        
        
        //Interfaz Map
        // Un Mapa representa un vector asociativo o diccionario.
        // Un vector con un indice de cualquier tipo.
        Map<String,String> mapa;
        
        //Implementación HashMap: Es la más veloz, pero no se garantiza el orden
        //mapa=new HashMap();
        
        //Implementación Hashtable: Es igual que HashMap pero es legacy(Obsoleta)
        //mapa=new Hashtable();
        
        //Implementación LinkedHashMap: Almacena elementos en una lista enlazada,
        // por orden de ingreso.
        mapa=new LinkedHashMap();
        
        //Implementación TreeMap:   Almacena elementos en un arbol, por orden natural
        //mapa=new TreeMap();
        
        
        //Aplicación
        mapa.put("lu", "Monday");
        System.out.println(mapa.get("lu"));
        mapa.put("lu", "Lunes");
        mapa.put("ma", "Martes");
        mapa.put("mi", "Miércoles");
        mapa.put("ju", "Jueves");
        mapa.put("vi", "Viernes");
        mapa.put("sa", "Sábado");
        mapa.put("do", "Domingo");
        
        System.out.println(mapa.get("lu"));
        System.out.println(mapa.get("vi"));
        System.out.println("*************************************************");
        //mapa.forEach((k,v)->System.out.println(k+" - "+v));
        mapa.keySet().forEach(k->System.out.println(k+" - "+mapa.get(k)));
        
        System.out.println("*************************************************");
        System.out.println(System.getProperties());
        System.getProperties().forEach((k,v)->System.out.println(k+" - "+v));
        System.out.println("*************************************************");
        System.out.println(System.getProperties().get("os.name"));
        System.out.println(System.getProperties().get("os.version"));
        System.out.println(System.getProperties().get("java.version"));
        System.out.println(System.getProperties().get("user.name"));
        System.out.println(System.getProperties().get("user.home"));
        System.out.println(System.getProperties().get("user.country"));
        System.out.println("*************************************************");
        System.getenv().forEach((k,v)->System.out.println(k+" - "+v));
        System.out.println(System.getenv().get("LANGUAGE"));
        
        
    }
}