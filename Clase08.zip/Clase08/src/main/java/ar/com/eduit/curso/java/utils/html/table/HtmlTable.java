package ar.com.eduit.curso.java.utils.html.table;
import java.lang.reflect.Field;
import java.util.List;
public class HtmlTable <E>{
    public String getTable(List<E>list){
        String table="";
        if(list==null || list.isEmpty()) return table;
        table+="<table>";
        E e=list.get(0);
        Field[] campos=e.getClass().getDeclaredFields();
        table+="<tr>";
        for(Field f:campos) table+="<th>"+f.getName()+"</th>";
        table+="</tr>";
        for(E o:list){
            table+="<tr>";
            for(Field f:campos){
                table+="<td>";
                String metodo="get"+f.getName().substring(0,1).toUpperCase()+f.getName().substring(1);
                //table+=metodo;
                try {
                    table+=o.getClass().getDeclaredMethod(metodo, null).invoke(o, null);
                } catch (Exception ex) {
                    System.out.println(ex);
                }
                table+="</td>";
            }
            table+="</tr>";
        }
        table+="</table>";
        return table;
    }
}