package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;
import java.util.List;

public class TestRepository {
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository(Connector.getConnection());
        Curso curso=new Curso("Java", "Vasquez", Dia.MARTES, Turno.NOCHE);
        cr.save(curso);
        System.out.println(curso);
        
        curso=cr.getById(2);
        System.out.println(curso);
        
        cr.remove(cr.getById(7));
        
        curso=cr.getById(6);
        curso.setTurno(Turno.MAÑANA);
        cr.update(curso);
        
        System.out.println("**************************************************");
        //List<Curso>list=cr.getAll();
        //for(int a=0;a<list.size();a++) System.out.println(list.get(a));
        
        cr.getAll().forEach(System.out::println);
        
        System.out.println("**************************************************");
        //list=cr.getLikeTitulo("ja");
        //for(int a=0;a<list.size();a++) System.out.println(list.get(a));
        
        cr.getLikeTitulo("ja").forEach(System.out::println);
        
        System.out.println("**************************************************");
        cr.getLikeTituloProfesor("ja", "va").forEach(System.out::println);
        
        System.out.println("**************************************************");
        System.out.println(cr.getById(3));
     
        
        System.out.println("**************************************************");
        I_AlumnoRepository ar=new AlumnoRepository(Connector.getConnection());
        Alumno alumno=new Alumno("Jesica", "Revoredo", 32, 1);
        ar.save(alumno);
        System.out.println(alumno);
        
        ar.remove(ar.getById(10));
        
        alumno=ar.getById(11);
        alumno.setNombre("Jimena");
        ar.update(alumno);
        
        System.out.println("**************************************************");
        ar.getAll().forEach(System.out::println);
        System.out.println("**************************************************");
        ar.getLikeApellido("ez").forEach(System.out::println);
        System.out.println("**************************************************");
        ar.getLikeCurso(cr.getById(3)).forEach(System.out::println);
        
        
    }
}